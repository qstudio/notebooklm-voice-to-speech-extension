
// Voice recognition functionality for Google NotebookLM
// Re-export from the new modular structure
export { startVoiceRecognition } from './voice/index.js';
